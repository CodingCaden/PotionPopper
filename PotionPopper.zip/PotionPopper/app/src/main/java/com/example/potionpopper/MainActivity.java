package com.example.potionpopper;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    int[] potions = {
            R.drawable.red,
    R.drawable.yellow,
    R.drawable.blue,
    R.drawable.green,
    R.drawable.purple,
    R.drawable.crystal
    };
    int widthOfBlock, noOfBlocks = 8, widthOfScreen;
    ArrayList<ImageView> potion = new ArrayList<>();
    int potionToBeDragged, potionToBeReplaced;
    int notPotion = R.drawable.transparent;
    Handler mHandler;
    int interval = 100;
    TextView scoreResult;
    TextView Timer;
    int score = 0;
    boolean hasWon = false;
    SharedPreferences sp;
    private Button button;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                System.exit(0);
            }
        });
        startTimer();
        scoreResult = findViewById(R.id.score);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        widthOfScreen = displayMetrics.widthPixels;
        int heightOfScreen = displayMetrics.heightPixels;
        widthOfBlock = widthOfScreen / noOfBlocks;
        createBoard();
        for (ImageView imageView : potion){
            imageView.setOnTouchListener(new OnSwipeListener(this)
            {
                @Override
                void onSwipeLeft() {
                    super.onSwipeLeft();
                    potionToBeDragged = imageView.getId();
                    potionToBeReplaced = potionToBeDragged -1;
                    potionInterChange();
                }

                @Override
                void onSwipeRight() {
                    super.onSwipeRight();
                    potionToBeDragged = imageView.getId();
                    potionToBeReplaced = potionToBeDragged +1;
                    potionInterChange();
                }

                @Override
                void onSwipeUp() {
                    super.onSwipeUp();
                    potionToBeDragged = imageView.getId();
                    potionToBeReplaced = potionToBeDragged - noOfBlocks;
                    potionInterChange();
                }

                @Override
                void onSwipeDown() {
                    super.onSwipeDown();
                    potionToBeDragged = imageView.getId();
                    potionToBeReplaced = potionToBeDragged + noOfBlocks;
                    potionInterChange();
                }
            });
        }
        mHandler = new Handler();
        startRepeat();
    }
    private void checkRowForThree(){
        for (int i = 0; i < 62; i++)
        {
            int chosePotion = (int) potion.get(i).getTag();
            boolean isBlank = (int) potion.get(i).getTag() == notPotion;
            Integer[] notValid = {6,7,14,15,22,23,30,31,38,39,46,47,54,55};
            List<Integer> list = Arrays.asList(notValid);
            if (!list.contains(i)){
                int x = i;
                if ((int) potion.get(x++).getTag() == chosePotion && !isBlank &&
                        (int) potion.get(x++).getTag() == chosePotion &&
                        (int) potion.get(x).getTag() == chosePotion)
                {
                    score = score + 3;
                    scoreResult.setText(String.valueOf(score));
                    potion.get(x).setImageResource(notPotion);
                    potion.get(x).setTag(notPotion);
                    x--;
                    potion.get(x).setImageResource(notPotion);
                    potion.get(x).setTag(notPotion);
                    x--;
                    potion.get(x).setImageResource(notPotion);
                    potion.get(x).setTag(notPotion);
                }
            }
        }
        movedDownPotions();
    }
    private void checkColForThree(){
        for (int i = 0; i < 47; i++)
        {
            int chosePotion = (int) potion.get(i).getTag();
            boolean isBlank = (int) potion.get(i).getTag() == notPotion;
                int x = i;
                if ((int) potion.get(x).getTag() == chosePotion && !isBlank &&
                        (int) potion.get(x+noOfBlocks).getTag() == chosePotion &&
                        (int) potion.get(x+2*noOfBlocks).getTag() == chosePotion)
                {
                    score = score + 3;
                    scoreResult.setText(String.valueOf(score));
                    potion.get(x).setImageResource(notPotion);
                    potion.get(x).setTag(notPotion);
                    x=x+noOfBlocks;
                    potion.get(x).setImageResource(notPotion);
                    potion.get(x).setTag(notPotion);
                    x=x+noOfBlocks;
                    potion.get(x).setImageResource(notPotion);
                    potion.get(x).setTag(notPotion);
                }
            }
        movedDownPotions();
        }
        private void startTimer(){
            Timer = findViewById(R.id.timer);
            // Time is in millisecond so 50sec = 50000 I have used
            // countdown Interveal is 1sec = 1000 I have used
            new CountDownTimer(50000, 1000) {
                public void onTick(long millisUntilFinished) {
                    // Used for formatting digit to be in 2 digits only
                    NumberFormat f = new DecimalFormat("00");
                    long hour = (millisUntilFinished / 3600000) % 24;
                    long min = (millisUntilFinished / 60000) % 60;
                    long sec = (millisUntilFinished / 1000) % 60;
                    Timer.setText(f.format(hour) + ":" + f.format(min) + ":" + f.format(sec));
                }
                // When the task is over it will print 00:00:00 there
                public void onFinish() {
                    Timer.setText("00:00:00");
                    startActivity(new Intent(MainActivity.this, GameOverScreen.class));
                }
            }.start();
        }
        private void saveScore(){
            sp = getSharedPreferences("MyUserPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sp.edit();
            editor.putInt("score", score);
            editor.commit();
        }
        private void movedDownPotions(){
        Integer[] firstRow = {0,1,2,3,4,5,6,7};
        List<Integer> list = Arrays.asList(firstRow);
        for (int i = 55; i >= 0; i--)
        {
            if((int)potion.get(i + noOfBlocks).getTag() == notPotion)
            {
                potion.get(i + noOfBlocks).setImageResource((int) potion.get(i).getTag());
                potion.get(i + noOfBlocks).setTag(potion.get(i).getTag());
                potion.get(i).setImageResource(notPotion);
                potion.get(i).setTag(notPotion);

                if(list.contains(i) && (int) potion.get(i).getTag() == notPotion)
                {
                    int randomColor = (int) Math.floor(Math.random() * potions.length);
                    potion.get(i).setImageResource(potions[randomColor]);
                    potion.get(i).setTag(potions[randomColor]);
                }
            }
        }
        for (int i = 0; i < 8; i++)
        {
            if((int) potion.get(i).getTag() == notPotion)
            {
                int randomColor = (int) Math.floor(Math.random() * potions.length);
                potion.get(i).setImageResource(potions[randomColor]);
                potion.get(i).setTag(potions[randomColor]);
            }
        }
    }
    Runnable repeatChecker = new Runnable() {
        @Override
        public void run() {
            try {
                saveScore();
                checkRowForThree();
                checkColForThree();
                movedDownPotions();
                if (hasWon == false) {
                    scoreCheck();
                }
            }
            finally {
                mHandler.postDelayed(repeatChecker, interval);
            }
        }
    };
    void startRepeat(){
        repeatChecker.run();
    }
    private void scoreCheck(){
        if (score >= 120 ) {
            finish();
            Intent intent = new Intent(getApplicationContext(), WinScreen.class);
            startActivity(intent);
            hasWon = true;
        }
    }
private void potionInterChange(){
    int background = (int) potion.get(potionToBeReplaced).getTag();
    int background1 = (int) potion.get(potionToBeDragged).getTag();
    potion.get(potionToBeDragged).setImageResource(background);
    potion.get(potionToBeReplaced).setImageResource(background1);
    potion.get(potionToBeDragged).setTag(background);
    potion.get(potionToBeReplaced).setTag(background1);
}
    private void createBoard() {
        GridLayout gridLayout = findViewById(R.id.board);
        gridLayout.setRowCount(noOfBlocks);
        gridLayout.setColumnCount(noOfBlocks);
        gridLayout.getLayoutParams().width = widthOfScreen;
        gridLayout.getLayoutParams().height = widthOfScreen;
        for(int i = 0; i < noOfBlocks * noOfBlocks ; i++){
            ImageView imageView = new ImageView(this);
            imageView.setId(i);
            imageView.setLayoutParams((new ViewGroup.LayoutParams(widthOfBlock, widthOfBlock)));
            imageView.setMaxHeight((widthOfBlock));
            imageView.setMaxWidth((widthOfBlock));
            int randomPotion = (int)Math.floor(Math.random() * potions.length);
            imageView.setImageResource(potions[randomPotion]);
            imageView.setTag(potions[randomPotion]);
            potion.add(imageView);
            gridLayout.addView(imageView);
        }
    }
}