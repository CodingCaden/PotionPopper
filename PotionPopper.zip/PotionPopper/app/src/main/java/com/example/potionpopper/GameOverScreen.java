package com.example.potionpopper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GameOverScreen extends AppCompatActivity {

    TextView scoreResult;
    TextView verbalScore;
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over_screen);
        scoreResult = findViewById(R.id.score);
        verbalScore = findViewById(R.id.VerbalScore);
        button = (Button) findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(GameOverScreen.this, MainActivity.class));
            }
        });
        SharedPreferences sp = getApplicationContext().getSharedPreferences("MyUserPrefs", Context.MODE_PRIVATE);
        int score = sp.getInt("score", 0);
        scoreResult.setText(String.valueOf(score));

        if(score >= 100)
        {
            verbalScore.setText("AMAZING ALMOST THERE!");
        }else if(70 <= score && score <= 99){
            verbalScore.setText("WOW YOU DID GREAT!");
        }else if(50 <= score && score <= 69){
            verbalScore.setText("YOU CAN DO BETTER!");
        }else{
            verbalScore.setText("HORRIBLE TRY AGAIN!");
        }
    }
}